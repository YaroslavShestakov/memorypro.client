/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package memorypro;

/**
 *
 * @author c2yshest
 */
public class User {
    public int id ;
    public String email ;
    public String password ;
    public String firstname ;
    public String lastname ;

    
}
