/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package memorypro;

/**
 *
 * @author Ярослав
 */
        
    public enum Error {
        NO_CONNECTION,
        WRONG_CREDENTIALS,
        BAD_DATA,
        UNKNOWN
    }