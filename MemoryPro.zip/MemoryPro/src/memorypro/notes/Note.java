package memorypro.notes;
import java.util.Date;
/**
 * A note class that contains info about a note object.
 * @author Jani Liikkanen
 */
public class Note {
    private Integer id ;
    private String title;
    private String description;
    private Date alertdate;
    private boolean enabled ;
    
    /**
     * Constructor for Note.
     * @param header Topic of the note.
     * @param message Message of the note.
     * @param date Date for note deadline.
     */
    public Note(String title, String description, Date date) {
        this.title = title ;
        this.description = description ;
        this.alertdate = date;
        this.enabled = true ;
    }
    
    /**
     * Constructor for Note.
     * @param header Topic of the note.
     * @param message Message of the note.
     */
    public Note(String title, String description) {
        this(title, description, new Date());
    }
    
    /**
     * Returns the header of the note.
     * @return Header of the note.
     */
    public String getTitle() {
        return title ;
    }
    
    /**
     * Returns the message of the note.
     * @return Message of the note.
     */
    public String getDescription() {
        return description ;
    }
    
    /**
     * returns the note alert date.
     * @return Deadline of the note.
     */
    public Date getDate() {
        return alertdate;
    }
    
    public boolean isEnabled(){
        return this.enabled ;
    }
    
    public boolean isActive(){
        return (this.alertdate.before(new Date())) ;
    }
    
    /**
     * Sets the header of a note.
     * @param newHeader New header for the note.
     */
    public void setTitle(String title){
        this.title = title ;
    }
    
    public void setEnabled(boolean status){
        this.enabled = status ;
    }
    
    /**
     * Sets the message of the note.
     * @param newMsg New message for the note.
     */
    public void setDescription(String description){
        this.description = description ;
    }
    
    public void setAlertDate(Date date){
        this.alertdate = date ;
    }
    

    
    /**
     * Returns a string containing data about the note.
     * @return String with info about the note.
     */
    @Override
    public String toString() {
        String strToReturn = title ;
        if (alertdate.toString() != null){
            strToReturn += " - " +  alertdate.toString();
        }
        return strToReturn;
    }

    public Date getAlertDate() {
        return this.alertdate ;
    }
}
